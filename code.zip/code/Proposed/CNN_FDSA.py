import pandas as pd
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten, BatchNormalization, Activation
from keras.layers import Conv2D, MaxPooling2D
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
# one hot encode outputs
from keras.utils import to_categorical
from keras.constraints import MaxNorm
import warnings
import logging, os
import tensorflow as tf
from keras.layers import Embedding, Input
from keras.models import Model

#from Main import Visualize
#from keras.utils import plot_model

warnings.filterwarnings('ignore', category=FutureWarning)
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
logging.getLogger('tensorflow').disabled = True
import warnings
warnings.filterwarnings("ignore")
import numpy as np


def cnn(X,Y, tr, Pre,Re,F):
    data = pd.read_csv(r'input.csv',header=None)
    data = np.array(data)
    lab = Y[:len(data)]
    X_train, X_test, y_train, y_test = train_test_split(data, lab, train_size=tr, random_state=42)
    # normalize inputs from 0-255 to 0.0-1.0
    X_train = X_train.astype('float32')
    X_test = X_test.astype('float32')
    X_train = (X_train)
    X_test = (X_test)
    y_train = to_categorical(y_train)
    y_test = to_categorical(y_test)
    num_classes = 1

    # Create the model
    model = Sequential()

    model.add(Conv2D(32, (3, 3), input_shape=(1, X_train.shape[1],1), padding='same'))
    model.add(Activation('relu'))
    model.add(Dropout(0.2))
    model.add(BatchNormalization())

    model.add(Conv2D(128, (3, 3), padding='same'))
    model.add(Activation('relu'))
    model.add(Dropout(0.2))
    model.add(BatchNormalization())

    model.add(Flatten())
    model.add(Dropout(0.2))

    model.add(Dense(256, kernel_constraint=MaxNorm(3)))
    model.add(Activation('relu'))
    model.add(Dropout(0.2))
    model.add(BatchNormalization())
    model.add(Dense(128, kernel_constraint=MaxNorm(3)))
    model.add(Activation('relu'))
    model.add(Dropout(0.2))
    model.add(BatchNormalization())
    model.add(Dense(num_classes))
    model.add(Activation('softmax'))
    epochs = 1
    optimizer = 'adam'
    model.compile(loss='mean_squared_error', optimizer=optimizer, metrics=['accuracy'])
    # model.summary()
    X_train = np.resize(X_train, (X_train.shape[0], 1, X_train.shape[1], 1))
    X_test = np.resize(X_test, (X_test.shape[0], 1, X_test.shape[1], 1))
    model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=epochs, batch_size=64, verbose=0)
    y_pred = model.predict(X_test)
    l1 = []
    for i in range(len(y_train)): l1.append(y_train[i][0])
    for i in range(len(y_pred)):
        if i == 0:
            l1.append(np.argmax(y_pred[i][0]))
        else:
            tem = []
            for j in range(len(y_pred[i])):
                tem.append(np.abs(y_pred[i][j] - y_pred[i - 1][j]))
            l1.append(np.argmax(tem))
    o1 = np.array(l1)

    #-------------------------------calculating weight------------------------------

    opt = tf.keras.optimizers.legacy.RMSprop()  #### weight
    m = tf.keras.models.Sequential([tf.keras.layers.Dense(2)])
    m.compile(opt, loss='mse')
    m.fit(data, lab)  # Training.
    w = m.get_weights()[0]

    #-----------------------------------------------------------

    y1 = 0
    for i in range(X.shape[0]):
        for j in range(X.shape[1]):
            y1=+ X[i][j] * w[j][0]

    #-----------------------------------------------------------

    alpha = 2
    o2 = alpha * y1 + (1/2) * alpha * o1

    #----------------------------------------------------------------------------------------

    L = np.resize(o2, (len(X), 1))
    Data = np.concatenate((X, L), axis=1)
    reg = LinearRegression().fit(Data, Y)
    Prediction = reg.predict(Data)
    Prediction = Prediction.astype('int')

    #------------------------------------Deep stacked autoencoder-----------------------------
    Prediction = np.resize(Prediction,(len(data),1))
    o3 = np.concatenate((data, Prediction), axis=1)
    X_train3, X_test3, y_train3, y_test3 = train_test_split(o3, lab, train_size=tr, random_state=1)
    sz = X_train3.shape
    input_img = Input(shape=(sz[1],))
    encoded = Dense(7, activation='relu')(input_img)
    encoded = Dense(6, activation='relu')(encoded)
    decoded = Dense(7, activation='relu')(encoded)
    decoded = Dense(sz[1], activation='sigmoid')(decoded)
    output = Dense(3, activation='softmax')(encoded)
    autoencoder = Model(input_img, output)
    autoencoder.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    y_binary1 = to_categorical(y_train3)
    y_binary2 = to_categorical(y_test3)

    autoencoder.fit(X_train3, y_binary1, epochs=10, batch_size=200)
    score = autoencoder.evaluate(X_test3, y_binary2, verbose=0)
    # making a prediction
    pred = autoencoder.predict(X_test3)
    o3 = (pred[:,0]).astype('int')

    target =y_test3

    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(target)  # unique label

    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(target)):
            if (target[i] == c and o3[i] == c): tp += 1
            if (target[i] != c and o3[i] != c): tn += 1
            if (target[i] == c and o3[i] != c): fn += 1
            if (target[i] != c and o3[i] == c): fp += 1

    acc = (tp + tn) / (tn + tp + fn + fp)  # accuracy
    precision = (tp / (tp + fp))
    recall = (tp / (tp + fn))               #Recall
    F1_score = 2 * ((precision * recall) / (precision + recall))  # F-measure
    Pre.append(precision)
    Re.append(recall)
    F.append(F1_score)

