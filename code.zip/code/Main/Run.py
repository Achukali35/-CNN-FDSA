import numpy as np
import pandas as pd
from Proposed import CNN_FDSA
import process
import simulation

simulation.run()
data, label = process.processsing()         # normalization, feature selection, augmentation
tr=0.9
Pre,Re,F = [],[],[]

#--------------------------------Proposed------------------------------

CNN_FDSA.cnn(data,label,tr,Pre,Re,F)


