import random, numpy as np

def augment_feat(data):
    ins_total = 10000

    c_min, c_max = [], []   # column min & max
    for i in range(len(data[0])):   # for each column
        col = np.array(data)[:, i]
        c_min.append(np.min(col))   # add min value
        c_max.append(np.max(col))   # add max value
    augmented_data = []
    for i in range(ins_total):
        tem = []
        for j in range(len(data[0])):
            if i >= len(data):
                # for extra instance generate random b/w min & max of that column
                tem.append(random.uniform(c_min[j], c_max[j]))
            else:
                tem.append(data[i][j])
        augmented_data.append(tem)
    return (np.array(augmented_data))

def augment_lab(data):
    ins_total = 10000

    c_min, c_max = [], []   # column min & max
    c_min.append(np.min(data))   # add min value
    c_max.append(np.max(data))   # add max value
    augmented_data = []
    for i in range(ins_total):
        tem = []
        if i >= len(data):
            # for extra instance generate random b/w min & max of that column
            tem.append(random.uniform(c_min[0], c_max[0]))
        else:
            tem.append(data[i])
        augmented_data.append(tem)
    return (np.array(augmented_data))

