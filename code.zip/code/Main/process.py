import pandas as pd
import numpy as np
from Main import cls_info_gain
from Main import Augmentation

def processsing():
    def quantile_normalize(df):
        df_sorted = pd.DataFrame(np.sort(df.values,
                                         axis=0),
                                 index=df.index,
                                 columns=df.columns)
        df_mean = df_sorted.mean(axis=1)
        df_mean.index = np.arange(1, len(df_mean) + 1)
        df_qn =df.rank(method="min").stack().astype(int).map(df_mean).unstack()
        return(df_qn)

    def manhatton_distance(X,Y):
        feat = []
        X = np.transpose(X)
        for i in range(len(X)):
            dis = Y - X[i]
            feat.append(dis)
        feat_sel_ = np.array(feat)
        feat_sel_ = np.transpose(feat_sel_)
        return feat_sel_
    input = pd.read_csv(r'data.csv',header=None)    # read dataset
    label = (np.array(input))[:,-1]
#-----------------------------------Quantile normalization----------------------------------

    nor = quantile_normalize(input)

#-------------------------------------Feature selection-------------------------------------

    data = np.array(nor)
    feat_len = cls_info_gain.Get_CIG(data,label)
    dist = manhatton_distance(data,label)
    sel_feat = dist[:,:feat_len]

#---------------------------------------Augmentation----------------------------------------

    aug_feat = Augmentation.augment_feat(sel_feat)
    aug_lab = Augmentation.augment_lab(label)
    return aug_feat,aug_lab
