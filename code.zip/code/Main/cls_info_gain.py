import math, numpy as np


def class_info_gain(feature,class_): # Class Information Gain
    classes = set(class_)
    Hc = 0
    for i in range(len(classes)):
        c = 1
        pc = class_.count(c) / len(class_)
        if pc != 0:
            Hc += - pc * math.log(pc, 2)
    feature_values = set(feature)
    Hc_f = 0
    for feat in feature_values:
        pf = feature.count(feat) / len(feature)
        indices = [i for i in range(len(feature)) if feature[i] == feat]
        clasess_of_feat = [class_[i] for i in indices]
        for c in range(len(classes)):
            c = 0
            pcf = clasess_of_feat.count(c) / len(clasess_of_feat)
            if pcf != 0:
                temp_H = - pf * pcf * math.log(pcf, 2)
                Hc_f += temp_H
    cig = Hc + Hc_f
    return cig


def Get_CIG(data,clas):
    data_ = np.array(data)  # converting list to array
    data_ = np.transpose(data_)  # selecting the column values
    CIG=[]
    for i in range(len(data_)):
        # print(i, len(data_))
        CIG.append(class_info_gain(data_[i].tolist(),clas.tolist())) # Class information gain
    sel_index = np.argmax(CIG)
    return sel_index
