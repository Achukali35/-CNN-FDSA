import csv, numpy, random, sys
import wsnsimpy.wsnsimpy_tk as wsp
def run():
    nodes=50
    rounds=500
    # parameter initialization
    print("\nSystem model..")
    n_nodes = nodes + 1  # no. of nodes(+base station)
    SOURCE, BASE_STATION = 0, n_nodes - 1  # source, destination(base station)

    # to place nodes over grid
    sq = int(numpy.sqrt(n_nodes))  # to make the nodes in square grid
    ex = n_nodes % sq  # excess nodes when make it square grid
    col_n = int((n_nodes - ex) / sq)  # columns for square grid
    m = []
    for i in range(col_n):
        m.append(sq)  #
    def node_creation(x_value, y_value):
        for x in range(col_n + 1):  # x columns1
            for y in range(m[0]):  # y rows
                px = 50 + x * 60 + random.uniform(-20, 20)  # node in x-axis at px
                x_value.append(px)
                py = 50 + y * 60 + random.uniform(-20, 20)  # node in y-axis at py
                y_value.append(py)


    # distance between nodes
    def distance(p1, p2):
        dist = numpy.sqrt((numpy.square(x_value[p2] - x_value[p1])) + (numpy.square(y_value[p2] - y_value[p1])))
        return dist


    # find the neighbours of each node
    def get_node_neighbours(x, y, n_nodes):
        neigh = []
        for i in range(n_nodes):  # for each node
            tem = []
            for j in range(n_nodes):  # find its neighbours
                if (i != j):
                    if (distance(i, j) < 100):
                        tem.append(j)  # nodes with min distance to the node is neighbour to that node
            neigh.append(tem)
        return neigh
    x_value, y_value = [], []  # x & y value of each node
    node_creation(x_value, y_value)

    # initial energy generation
    def generate(v):
        data = []
        for i in range(nodes):
            data.append(v)  # initial energy of all nodes is 1
        return data


    # packets to be send by each node, mobility, direction
    def node_packet_speed_dir(nod):
        dp, ms, dm = [], [], []
        for i in range(rounds):
            tem_1, tem_2, tem_3 = [], [], []
            for j in range(nod):
                tem_1.append(random.randint(1, 10))
                tem_2.append(random.randint(1, 10))
                tem_3.append(random.uniform(0, (2 * 3.14)))  # random(0, 2*pi)
            dp.append(tem_1)  # data packet
            ms.append(tem_2)  # mobility speed
            dm.append(tem_3)  # direction of motion
        return dp, ms, dm


    def view_bar(job_title, progress):
        length = 20  # modify this to change the length
        block = int(round(length * progress))
        msg = "\r{0}: [{1}] {2}%".format(job_title, "#" * block + "-" * (length - block), round(progress * 100, 2))
        if progress >= 1: msg += " DONE\r\n"
        sys.stdout.write(msg)
        sys.stdout.flush()



    # def run():

    class MyNode(wsp.Node):
        tx_range = 50

        ###################
        def run(self):  # loop until nodes
            yield self.timeout(1)  # shows created nodes

            for i in range(600):   # n_nodes
                if self.id is source:
                    self.scene.nodecolor(self.id, 0, .9, 0)  # if source node, node color => blue
                    self.scene.nodewidth(self.id, 2)


                else:
                    if self.id is BASE_STATION:
                        self.scene.nodecolor(self.id, 0, .9, 0)  # if node is Base station, node color => red
                        self.scene.nodewidth(self.id, 2)
                    else:
                        self.scene.nodecolor(self.id, 0, .9, 0)  # else, other node color => green

                # for i in range(len(dead_nodes)):  # dead node will be disabled
                #     if self.id is dead_nodes[i]:
                #         self.scene.nodecolor(self.id, .7, .7, .7)  # node color => grey (disable)

            #
            # for i in range(len(Final_path) - 1):
            #     if self.id is Final_path[i]:
            #         self.scene.nodecolor(self.id, 0, 0, 1)  # node color => blue
            #         self.start_process(self.start_send_data(Final_path[i + 1]))  # source, destination

        ###################
        def start_send_data(self, dest):
            seq = 0

            while True:
                yield self.timeout(0.2)  # transmission will be displayed after 0.5s
                self.scene.clearlinks()
                d = random.uniform(.3, .9)  # uniform value between 0.3 - 0.9
                yield self.timeout(d)  # timeout of the link between nodes
                self.send_data(dest)  # source, dest
                seq += 1

        ###################
        def send_data(self, dest):
            self.send(dest, msg='data', src=self.id)

    source = 0
    WS = col_n * 70  # window size

    # simulation will display for 15s
    sim = wsp.Simulator(until=15, timescale=1, visual=True, terrain_size=(WS, WS), title="@ Round " + str(
        rounds))  # simulation window (15s,True - to display, ter -- wnd. size, tit -- wnd. title)

    for i in range(len(x_value)):  # x columns1
        px, py = x_value[i], y_value[i]
        node = sim.add_node(MyNode, (px, py))  # create node at (px,py)

    # start the simulation
    sim.run()
# run()
